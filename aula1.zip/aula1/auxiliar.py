import pyautogui 
import time

time.sleep(5)
print(pyautogui.position())