# (dica):
# primeira coisa que fazer em qualquer codigo o passo a passo do meu projeto, para depois traduzir para o python

# -passo 1 : entrar no sistema da empresa
# -passo 2 : fazer login
# -passo 3 : abrir a base de dados
# -passo 4 : cadrastrar um produto
# -passo 5 : repitir o passo 4 até cadrastrar todos os produtos


# *PYAUTOGUI : blibioteca
# *instalar a blibioteca no terminal
# "pip intall pyautogui"
# *importar o pyautogui no projeto

import pyautogui
import time
import pandas

#comandos :
# pyautogui.click - clicar com o mouse
# pyautogui.write - excrever um texto
# pyautogui.press - vai apertar um tecla
# pyautogui.hotkey - combinação de teclas
# pyautogui.scroll - rolar a tela para cima ou para baixo

# -passo 1 : entrar no sistema da empresa
pyautogui.PAUSE = 0.5
#link : https://dlp.hashtagtreinamentos.com/python/intensivao/login
pyautogui.press("win")
pyautogui.write("chrome")
time.sleep(1)
pyautogui.press("enter")
time.sleep(5)
pyautogui.write("https://dlp.hashtagtreinamentos.com/python/intensivao/login")
pyautogui.press("enter")
time.sleep(3)

# -passo 2 : fazer login
pyautogui.click(x=510, y=368)
pyautogui.hotkey("ctrl", "a")
pyautogui.press("tab")
pyautogui.write("matheus@gmail.com")

# passar para o campo de senha
pyautogui.press("tab")
pyautogui.write("minha senha")

# botão de logar
pyautogui.press("tab")
pyautogui.press("enter")
time.sleep(3)

# -passo 3 : abrir a base de dados

#para ler a base de dados
tabela = pandas.read_csv("produtos.csv")

# -passo 4 : cadrastrar um produto
# for linha in tabela.index:
pyautogui.click(x=429, y=283)  

    # teste = 1
    # while teste < 3:
    #     print(teste)
    #     teste += 1  
    #     break
    # codigo = str(tabela.loc[linha,"codigo"])
pyautogui.write("codigo")

    #marca
pyautogui.press("tab")
    # marca = str(tabela.loc[linha,"marca"])
pyautogui.write("marca")

    #tipo
pyautogui.press("tab")
    # tipo = str(tabela.loc[linha,"tipo"])
pyautogui.write("tipo")

    #categoria
pyautogui.press("tab")
    # categoria = str(tabela.loc[linha,"categoria"])
pyautogui.write("categoria")

    #preco
pyautogui.press("tab")
    # preco = str(tabela.loc[linha,"preco_unitario"])
pyautogui.write("preco")

    #custo
pyautogui.press("tab")
    # custo = str(tabela.loc[linha,"custo"])
pyautogui.write("custo")

    #obs
pyautogui.press("tab")
    # obs = str(tabela.loc[linha,"obs"])
    # if obs != "nan":
pyautogui.write("obs")
          

    #apertar o botão de enviar
pyautogui.press("tab")
pyautogui.press("enter")

pyautogui.scroll(5000)

# -passo 5 : repitir o passo 4 até cadrastrar todos os produtos